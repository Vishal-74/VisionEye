# Fighting detection  > 2024-04-19 12:32pm
https://universe.roboflow.com/project01-fbz65/fighting-detection-njtsd

Provided by a Roboflow user
License: CC BY 4.0

